// You can define your Supabase types here or use `any` if not yet set up.
export type Database = any
